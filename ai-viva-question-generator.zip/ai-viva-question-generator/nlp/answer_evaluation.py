"""Module 5 - automatic answer evaluation.

Score = 10 * (w_tfidf * TF-IDF cosine + w_semantic * embedding cosine + w_coverage * concept coverage)

Weights are configurable below (or via environment variables). If sentence-transformers is
not installed, the semantic weight is redistributed and the TF-IDF fallback is used.

LIMITATIONS: this measures textual overlap with the reference answer, NOT factual
correctness. A fluent wrong answer that reuses the reference vocabulary can score well,
and a correct answer phrased very differently can score poorly. Treat scores as guidance.
"""
import os
import re

from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity

from nlp.preprocessing import normalize_text, stem

# ---- configurable scoring formula -----------------------------------------------------
WEIGHTS_TFIDF_ONLY = {"tfidf": 0.40, "coverage": 0.60}
WEIGHTS_WITH_SEMANTIC = {"tfidf": 0.20, "semantic": 0.30, "coverage": 0.50}
CORRECT_THRESHOLD = 7.0   # score >= 7  -> "correct"
PARTIAL_THRESHOLD = 4.0   # 4 <= score < 7 -> "partial", below -> "weak"
USE_SEMANTIC = os.environ.get("USE_SEMANTIC", "1") == "1"
SEMANTIC_MODEL = "all-MiniLM-L6-v2"
# ---------------------------------------------------------------------------------------

# Discourse/filler words that are not subject concepts and should not be demanded from the student.
NON_CONCEPTS = {"unlike", "whereas", "however", "therefore", "because", "thus", "also", "such", "like", "often",
                "commonly", "widely", "main", "mean", "many", "much", "cannot", "can", "may", "could", "need", "produce"}

_st_model = None
_st_failed = False


def _semantic_model():
    """Lazy-load the optional sentence-transformer; returns None if unavailable."""
    global _st_model, _st_failed
    if not USE_SEMANTIC or _st_failed:
        return None
    if _st_model is None:
        try:
            from sentence_transformers import SentenceTransformer
            _st_model = SentenceTransformer(SEMANTIC_MODEL)
        except Exception:
            _st_failed = True
            return None
    return _st_model


def semantic_available():
    return _semantic_model() is not None


def reference_concepts(reference, max_concepts=8):
    """Key concepts = distinct content-word lemmas of the reference answer (longer words first)."""
    lemmas = [w for w in normalize_text(reference) if len(w) > 2 and not w.isdigit() and w not in NON_CONCEPTS]
    uniq = list(dict.fromkeys(lemmas))
    uniq.sort(key=lambda w: -len(w))
    return uniq[:max_concepts]


def concept_coverage(answer, concepts):
    """Which reference concepts appear in the student's answer (lemma or stem match)."""
    ans_lemmas = set(normalize_text(answer))
    ans_stems = set(stem(list(ans_lemmas)))
    found, missing = [], []
    for c in concepts:
        if c in ans_lemmas or stem([c])[0] in ans_stems:
            found.append(c)
        else:
            missing.append(c)
    return found, missing


def tfidf_similarity(answer, reference):
    a, r = " ".join(normalize_text(answer)), " ".join(normalize_text(reference))
    if not a or not r:
        return 0.0
    try:
        vec = TfidfVectorizer(ngram_range=(1, 2), sublinear_tf=True)
        m = vec.fit_transform([r, a])
        return float(cosine_similarity(m[0], m[1])[0][0])
    except ValueError:
        return 0.0


def semantic_similarity(answer, reference):
    model = _semantic_model()
    if model is None:
        return None
    emb = model.encode([reference, answer])
    return max(0.0, float(cosine_similarity([emb[0]], [emb[1]])[0][0]))


def _feedback(score, found, missing, answer):
    if not answer.strip():
        return "No answer was provided."
    if len(answer.split()) < 4:
        tip = "Your answer is very short - write at least one or two full sentences. "
    else:
        tip = ""
    if score >= CORRECT_THRESHOLD:
        base = "Good answer - it covers most of the key ideas."
    elif score >= PARTIAL_THRESHOLD:
        base = "Partially correct - you have some key ideas but the answer is incomplete."
    else:
        base = "Weak answer - revise this topic and compare with the reference answer."
    if missing:
        base += " Try to mention: " + ", ".join(missing[:5]) + "."
    return tip + base


def status_for(score):
    if score >= CORRECT_THRESHOLD:
        return "correct"
    if score >= PARTIAL_THRESHOLD:
        return "partial"
    return "weak"


def evaluate_answer(answer, reference):
    """Compare a student answer with the reference. Returns a dict with score (0-10) and feedback."""
    answer = (answer or "").strip()
    concepts = reference_concepts(reference)
    if not answer:
        return {"score": 0.0, "similarity": 0.0, "tfidf_similarity": 0.0, "semantic_similarity": None,
                "coverage": 0.0, "found": [], "missing": concepts, "status": "weak",
                "feedback": "No answer was provided.", "method": "none"}
    found, missing = concept_coverage(answer, concepts)
    coverage = len(found) / len(concepts) if concepts else 0.0
    tf = tfidf_similarity(answer, reference)
    sem = semantic_similarity(answer, reference)
    if sem is None:
        w = WEIGHTS_TFIDF_ONLY
        combined = w["tfidf"] * tf + w["coverage"] * coverage
        method, similarity = "TF-IDF + concept coverage", tf
    else:
        w = WEIGHTS_WITH_SEMANTIC
        combined = w["tfidf"] * tf + w["semantic"] * sem + w["coverage"] * coverage
        method, similarity = "TF-IDF + semantic + concept coverage", (tf + sem) / 2
    # Light length guard: one-word answers cannot earn a high mark by keyword luck.
    if len(answer.split()) < 3:
        combined *= 0.5
    score = round(min(10.0, combined * 10), 1)
    return {"score": score, "similarity": round(similarity * 100, 1), "tfidf_similarity": round(tf * 100, 1),
            "semantic_similarity": None if sem is None else round(sem * 100, 1),
            "coverage": round(coverage * 100, 1), "found": found, "missing": missing,
            "status": status_for(score), "feedback": _feedback(score, found, missing, answer), "method": method}
