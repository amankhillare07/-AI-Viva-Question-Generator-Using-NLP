"""TF-IDF keyword extraction and important-sentence ranking."""
import re

from sklearn.feature_extraction.text import TfidfVectorizer

from nlp.preprocessing import split_sentences, normalize_text

# Generic words that TF-IDF can rank highly but that make poor topics.
GENERIC = {"word", "words", "used", "use", "uses", "using", "text", "texts", "called", "such", "like", "common",
           "commonly", "form", "type", "types", "helps", "help", "main", "first", "step", "steps", "widely", "also",
           "many", "most", "much", "close", "means", "mean", "unit", "units", "technique", "techniques", "field",
           "term", "terms", "value", "values", "number", "kind", "way", "ways", "thing", "things", "popular", "key",
           "meaning", "removing", "remove", "order", "angle", "reflects", "measures", "enables", "assigns", "identifies", "captures", "produces", "reduces", "allows"}
_WORDISH = re.compile(r"^[a-z][a-z\-]{2,}( [a-z][a-z\-]{2,})?$")


def extract_keywords(text, top_n=15):
    """Rank unigrams and bigrams by TF-IDF, treating each sentence as a 'document'.

    TF-IDF weights a term highly if it appears often in a few sentences but not in all of
    them, which favours topical terms over filler words. Returns [(term, score), ...].
    """
    sentences = split_sentences(text)
    if len(sentences) < 2:
        sentences = sentences + re.split(r"[;,]", text) if sentences else []
    sentences = [s for s in sentences if s.strip()]
    if not sentences:
        return []
    try:
        vec = TfidfVectorizer(stop_words="english", ngram_range=(1, 2), token_pattern=r"(?u)\b[a-zA-Z][a-zA-Z\-]{2,}\b",
                              lowercase=True, sublinear_tf=True)
        matrix = vec.fit_transform(sentences)
    except ValueError:  # empty vocabulary
        return []
    scores = matrix.sum(axis=0).A1
    terms = vec.get_feature_names_out()
    ranked = sorted(zip(terms, scores), key=lambda x: -x[1])
    out, taken = [], []
    for term, sc in ranked:
        if not _WORDISH.match(term) or any(w in GENERIC for w in term.split()):
            continue
        if any(term in t or t in term for t, _ in taken):  # avoid 'tokenization' + 'tokenization process'
            continue
        taken.append((term, sc))
        out.append((term, round(float(sc), 3)))
        if len(out) >= top_n:
            break
    return out


def rank_sentences(text, top_n=10):
    """Score sentences by the TF-IDF weight of the keywords they contain (extractive importance)."""
    sentences = split_sentences(text)
    kw = dict(extract_keywords(text, top_n=40))
    scored = []
    for i, s in enumerate(sentences):
        low = s.lower()
        score = sum(w for k, w in kw.items() if k in low)
        score = score / (len(s.split()) ** 0.5 + 1)  # mild length normalisation
        scored.append((i, s, round(score, 4)))
    scored.sort(key=lambda x: -x[2])
    return scored[:top_n]


def topic_for_sentence(sentence, keywords):
    """Assign a topic label to a sentence: the highest ranked keyword it contains."""
    low = sentence.lower()
    for k, _ in keywords:
        if k in low:
            return k
    toks = normalize_text(sentence)
    return toks[0] if toks else "general"
