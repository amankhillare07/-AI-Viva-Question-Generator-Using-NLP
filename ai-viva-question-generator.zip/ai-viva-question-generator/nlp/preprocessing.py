"""Module 2 - NLP text preprocessing pipeline (NLTK + spaCy)."""
import re
import string
from collections import Counter

import nltk
from nltk.corpus import stopwords, wordnet
from nltk.stem import PorterStemmer, WordNetLemmatizer
from nltk.tokenize import sent_tokenize, word_tokenize

_REQUIRED = {
    "punkt": "tokenizers/punkt", "punkt_tab": "tokenizers/punkt_tab",
    "stopwords": "corpora/stopwords", "wordnet": "corpora/wordnet",
    "omw-1.4": "corpora/omw-1.4",
    "averaged_perceptron_tagger": "taggers/averaged_perceptron_tagger",
    "averaged_perceptron_tagger_eng": "taggers/averaged_perceptron_tagger_eng",
}


def ensure_nltk_data():
    """Download any missing NLTK resource (safe to call repeatedly)."""
    for pkg, path in _REQUIRED.items():
        try:
            nltk.data.find(path)
        except LookupError:
            try:
                nltk.download(pkg, quiet=True)
            except Exception:
                pass


ensure_nltk_data()

_stemmer = PorterStemmer()
_lemmatizer = WordNetLemmatizer()
_STOP = set(stopwords.words("english"))
_nlp = None
_nlp_failed = False


def get_spacy():
    """Lazy-load spaCy. Returns None if the model is missing (NER is then skipped)."""
    global _nlp, _nlp_failed
    if _nlp is None and not _nlp_failed:
        try:
            import spacy
            _nlp = spacy.load("en_core_web_sm")
        except Exception:
            _nlp_failed = True
    return _nlp


def clean_text(text):
    """Normalise whitespace and fix words hyphenated across PDF line breaks."""
    text = text.replace("\r", "\n")
    text = re.sub(r"(\w)-\n(\w)", r"\1\2", text)
    text = re.sub(r"\n{2,}", "\n\n", text)
    text = re.sub(r"(?<!\n)\n(?!\n)", " ", text)  # single newlines -> spaces
    text = re.sub(r"[ \t]+", " ", text)
    return text.strip()


def split_sentences(text):
    """1. Sentence segmentation. Original sentences are preserved for question generation."""
    sents = []
    for block in re.split(r"\n\s*\n", clean_text(text)):
        for s in sent_tokenize(block):
            s = s.strip()
            if len(s.split()) >= 3:
                sents.append(s)
    return sents


def tokenize(text):
    """2. Word tokenisation."""
    return word_tokenize(text)


def remove_punct(tokens):
    """5. Punctuation removal (keeps tokens that contain at least one letter/digit)."""
    return [t for t in tokens if any(c.isalnum() for c in t) and t not in string.punctuation]


def remove_stopwords(tokens):
    """4. Stop-word removal."""
    return [t for t in tokens if t not in _STOP]


def stem(tokens):
    """6. Porter stemming (crude suffix stripping: 'studies' -> 'studi')."""
    return [_stemmer.stem(t) for t in tokens]


def _wn_pos(tag):
    return {"J": wordnet.ADJ, "V": wordnet.VERB, "N": wordnet.NOUN, "R": wordnet.ADV}.get(tag[0], wordnet.NOUN)


def pos_tag(tokens):
    """8. Part-of-speech tagging (Penn Treebank tags via NLTK)."""
    return nltk.pos_tag(tokens)


def lemmatize(tokens):
    """7. WordNet lemmatisation, guided by POS ('running' -> 'run', 'better' -> 'good')."""
    return [_lemmatizer.lemmatize(w, _wn_pos(t)) for w, t in pos_tag(tokens)]


def normalize_text(text):
    """Lowercase -> tokenise -> drop punctuation/stop-words -> lemmatise. Used for matching."""
    toks = remove_punct(tokenize(text.lower()))
    toks = remove_stopwords(toks)
    return lemmatize(toks)


def named_entities(text, limit=2000000):
    """9. Named Entity Recognition with spaCy. Returns [] when the model is unavailable."""
    nlp = get_spacy()
    if nlp is None:
        return []
    doc = nlp(text[:100000])
    seen, ents = set(), []
    for e in doc.ents:
        key = (e.text.strip(), e.label_)
        if key not in seen and len(e.text.strip()) > 1:
            seen.add(key)
            ents.append({"text": e.text.strip(), "label": e.label_})
    return ents


def ngrams(tokens, n=2):
    """10. N-gram extraction."""
    return list(zip(*[tokens[i:] for i in range(n)]))


def word_frequency(tokens, top=15):
    """11. Word-frequency analysis."""
    return Counter(tokens).most_common(top)


def analyze(text):
    """Run the full pipeline and return a JSON-friendly report for the NLP Analysis page."""
    from nlp.keyword_extraction import extract_keywords
    sentences = split_sentences(text)
    sample_sentence = sentences[0] if sentences else ""
    raw_tokens = tokenize(text.lower()) if text else []
    no_punct = remove_punct(raw_tokens)
    no_stop = remove_stopwords(no_punct)
    lemmas = lemmatize(no_stop[:5000])
    sample_tokens = remove_punct(tokenize(sample_sentence))[:15]
    tagged = pos_tag(sample_tokens)
    bigrams = Counter(ngrams(no_stop, 2)).most_common(10)
    trigrams = Counter(ngrams(no_stop, 3)).most_common(8)
    stems_demo = [(w, _stemmer.stem(w), _lemmatizer.lemmatize(w, wordnet.VERB)) for w in dict.fromkeys(no_stop[:60])][:12]
    return {
        "stats": {"words": len([t for t in raw_tokens if any(c.isalnum() for c in t)]),
                  "sentences": len(sentences), "unique_words": len(set(no_stop)),
                  "after_stopword_removal": len(no_stop)},
        "sample_sentence": sample_sentence,
        "tokens": sample_tokens,
        "pos_tags": tagged,
        "stem_vs_lemma": stems_demo,
        "entities": named_entities(text)[:30],
        "spacy_available": get_spacy() is not None,
        "bigrams": [(" ".join(g), c) for g, c in bigrams],
        "trigrams": [(" ".join(g), c) for g, c in trigrams],
        "frequency": word_frequency(lemmas, 15),
        "keywords": extract_keywords(text, top_n=15),
    }
