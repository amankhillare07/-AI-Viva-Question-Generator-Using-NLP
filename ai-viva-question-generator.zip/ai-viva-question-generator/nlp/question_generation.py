"""Module 3 - rule-based question generation.

Method: sentence segmentation -> pattern matching on sentence structure (definitions,
causes, comparisons, advantages/limitations, applications), spaCy NER for Who/When/Where,
and TF-IDF keywords for concept-linking questions. Every question carries the source
passage and a reference answer taken from that passage.

LIMITATION: these are templates over surface patterns, NOT human-level understanding.
Questions are only as good as the source text; some will be awkward and should be reviewed.
"""
import re

from nlp.keyword_extraction import extract_keywords, topic_for_sentence
from nlp.preprocessing import get_spacy, split_sentences

METHOD = "Rule-based"
LEVELS = ["Easy", "Medium", "Difficult"]

_DEF = re.compile(
    r"^(?P<subj>(?:[A-Z][\w\-/\(\)']*|[a-z][\w\-]*)(?:\s+[\w\-/\(\)']+){0,5}?)\s+"
    r"(?P<verb>is defined as|can be defined as|is called|refers to|is|are|means)\s+(?P<rest>.{12,})$")
_BAD_SUBJ = {"it", "this", "that", "these", "those", "there", "which", "he", "she", "they", "one", "who", "what"}
_CAUSE = re.compile(r"\b(because|since|so that|due to|as a result|therefore|which is why|so )\b", re.I)
_COMPARE = re.compile(r"\b(unlike|whereas|while|in contrast|compared (?:to|with)|more [a-z]+ than|[a-z]+er than|difference|however)\b", re.I)
_PROCESS = re.compile(r"\b(first|then|next|finally|step|process of|works by|by (?:[a-z]+ing)|steps?)\b", re.I)
_ADV_LIM = re.compile(r"\b(advantages?|benefits?|limitations?|drawbacks?|disadvantages?|cannot|ignores?|however|downside|hurt)\b", re.I)
_APPLY = re.compile(r"\b(used (?:in|for|to)|applications?|applied|widely used|helps? in|useful)\b", re.I)


def _strip_article(s):
    return re.sub(r"^(the|a|an)\s+", "", s.strip(), flags=re.I).strip(" ,.;:")


def _valid_subject(subj):
    s = _strip_article(subj)
    if not s or s.lower() in _BAD_SUBJ or len(s.split()) > 6:
        return None
    if re.search(r"\b(is|are|was|were|can|will|has|have)\b", s.lower()):
        return None
    return s


def _passage(sentences, i, span=2):
    return " ".join(sentences[i:i + span])


def _q(level, qtype, question, answer, source, topic):
    return {"difficulty": level, "qtype": qtype, "question": question.strip(), "answer": answer.strip(),
            "source": source.strip(), "topic": topic, "method": METHOD}


def _easy(sentences, keywords):
    out, defined = [], set()
    nlp = get_spacy()
    for i, s in enumerate(sentences):
        m = _DEF.match(s.rstrip(".!"))
        if m:
            subj = _valid_subject(m.group("subj"))
            if subj and len(subj.split()) <= 6:
                plural = m.group("verb") == "are"
                q = f"What {'are' if plural else 'is'} {subj}?"
                out.append(_q("Easy", "Definition", q, s, s, subj.lower()))
                defined.add(subj.lower())
    # Who / When / Where from named entities
    if nlp:
        for s in sentences:
            doc = nlp(s)
            for ent in doc.ents:
                topic = topic_for_sentence(s, keywords)
                if ent.label_ == "PERSON" and ent.start_char <= 1 and len(doc) > ent.end + 1 and doc[ent.end].pos_ == "VERB":
                    out.append(_q("Easy", "Who", "Who " + s[ent.end_char:].strip().rstrip(".") + "?", s, s, topic))
                elif ent.label_ in ("DATE",) and re.search(r"\b\d{4}\b", ent.text):
                    blank = s.replace(ent.text, "____")
                    out.append(_q("Easy", "When", f"When did this happen, according to the notes? \"{blank}\"", s, s, topic))
                elif ent.label_ in ("GPE", "LOC", "FAC") and ent.start > 0 and doc[ent.start - 1].lower_ in ("in", "at", "near", "from", "inside"):
                    blank = s.replace(ent.text, "____")
                    out.append(_q("Easy", "Where", f"Where does this take place, according to the notes? \"{blank}\"", s, s, topic))
    # Terminology: quoted or capitalised key terms
    for kw, _ in keywords[:8]:
        if any(kw in d or d in kw for d in defined):
            continue
        for s in sentences:
            if kw in s.lower():
                out.append(_q("Easy", "Terminology", f"What is the role or meaning of '{kw}' in this material?", s, s, kw))
                break
    return out


def _medium(sentences, keywords):
    out = []
    for i, s in enumerate(sentences):
        topic = topic_for_sentence(s, keywords)
        passage = _passage(sentences, i, 2)
        m = _DEF.match(s.rstrip(".!"))
        subj = _valid_subject(m.group("subj")) if m else None
        if _COMPARE.search(s) and not re.match(r"^however", s, re.I):
            pair = re.findall(r"\b([A-Z][a-z]+(?:ization|ing|ization)?|stemming|lemmatization|[A-Za-z\-]+)\b", s)
            topics = [k for k, _ in keywords if k in s.lower()][:2]
            if len(topics) == 2:
                out.append(_q("Medium", "Comparison", f"Explain the difference between {topics[0]} and {topics[1]}.", passage, passage, topic))
            else:
                out.append(_q("Medium", "Comparison", f"Compare the ideas contrasted in this statement: \"{s}\" - what distinguishes them?", passage, passage, topic))
        if _CAUSE.search(s) and len(s.split()) > 7:
            clause = _CAUSE.split(s)[0].strip(" ,")
            wm = re.match(r"^(?P<subj>.{3,60}?)\s+(?P<v>is|are)\s+(?P<rest>.+)$", clause)
            if wm and _valid_subject(wm.group("subj")):
                out.append(_q("Medium", "Why", f"Why {wm.group('v')} {_valid_subject(wm.group('subj'))} {wm.group('rest')}?", s, s, topic))
            elif len(clause.split()) >= 4:
                out.append(_q("Medium", "Why", f"Why does the following hold: \"{clause}\"?", s, s, topic))
        if subj and _PROCESS.search(s):
            out.append(_q("Medium", "How", f"How does {subj} work, or what is its process?", passage, passage, subj.lower()))
        elif subj and i + 1 < len(sentences):
            out.append(_q("Medium", "Explain", f"Explain {subj} and describe its key characteristics.", passage, passage, subj.lower()))
    # relationship between two co-occurring keywords
    top = [k for k, _ in keywords[:10]]
    for i, s in enumerate(sentences):
        present = [k for k in top if k in s.lower()]
        if len(present) >= 2:
            out.append(_q("Medium", "Relationship", f"Explain the relationship between {present[0]} and {present[1]}.",
                          _passage(sentences, i, 2), _passage(sentences, i, 2), present[0]))
    return out


def _difficult(sentences, keywords):
    out = []
    for i, s in enumerate(sentences):
        topic = topic_for_sentence(s, keywords)
        passage = _passage(sentences, max(0, i - 1) if i + 1 >= len(sentences) else i, 2)
        subj_m = re.match(r"^(?:The\s+)?(?P<s>[A-Z][\w\-]*(?:\s+[A-Za-z\-]+){0,3}?)\s+(?:is|are|can|cannot|has|ignores|multiplies)\b", s)
        subj = _valid_subject(subj_m.group("s")) if subj_m else None
        if re.search(r"\b(advantages?|benefits?|limitations?|drawbacks?|disadvantages?|cannot|ignores?|hurt)\b", s, re.I):
            t = topic if topic != "general" else (subj or topic)
            out.append(_q("Difficult", "Advantages/Limitations",
                          f"Discuss the advantages and limitations of {t}, and explain a situation where the limitation would matter.",
                          passage, passage, t))
        if _APPLY.search(s):
            t = subj or topic
            out.append(_q("Difficult", "Application", f"Describe the applications of {t} mentioned in the notes and justify why it suits those uses.",
                          passage, passage, t))
        if re.search(r"\b(more useful|better|more [a-z]+ than|cannot capture|unlike)\b", s, re.I) and len(s.split()) > 8:
            out.append(_q("Difficult", "Analysis", f"Critically analyse this claim from the notes: \"{s}\"", passage, passage, topic))
    # connections between keywords from different parts of the document
    # Only recurring concepts (mentioned in 2+ sentences) are linked, so tiny texts don't yield junk pairs.
    top = [k for k, _ in keywords[:12] if sum(k in s.lower() for s in sentences) >= 2]
    for a in range(len(top)):
        for b in range(a + 1, len(top)):
            sa = [i for i, s in enumerate(sentences) if top[a] in s.lower()]
            sb = [i for i, s in enumerate(sentences) if top[b] in s.lower()]
            if sa and sb and not set(sa) & set(sb) and len(out) < 400:
                ia, ib = sa[0], sb[0]
                ref = sentences[ia] + " " + sentences[ib]
                out.append(_q("Difficult", "Connection",
                              f"How are {top[a]} and {top[b]} connected, and how might they be used together?", ref, ref, top[a]))
    return out


def _norm(q):
    return re.sub(r"[^a-z0-9 ]", "", q.lower())


def generate_questions(text, difficulty="All", count=10, doc_keywords=None):
    """Generate questions grounded in `text`.

    Returns {"questions": [...], "notes": [...]} where notes explain any shortfall
    instead of inventing content.
    """
    sentences = split_sentences(text)
    notes = []
    if len(sentences) < 3:
        return {"questions": [], "notes": ["The material is too short (fewer than 3 sentences) to generate meaningful questions."]}
    keywords = doc_keywords or extract_keywords(text, top_n=20)
    builders = {"Easy": _easy, "Medium": _medium, "Difficult": _difficult}
    levels = LEVELS if difficulty in ("All", None, "") else [difficulty]
    pools = {}
    for lv in levels:
        seen_q, seen_src, pool = set(), {}, []
        for item in builders[lv](sentences, keywords):
            n = _norm(item["question"])
            if n in seen_q or len(item["question"].split()) < 3:
                continue
            key = (item["qtype"], item["source"][:60])
            if seen_src.get(key, 0) >= 1:  # at most one question of a type per source passage
                continue
            seen_q.add(n)
            seen_src[key] = 1
            pool.append(item)
        pools[lv] = pool
        if not pool:
            notes.append(f"The material does not contain enough suitable patterns to generate {lv} questions "
                         f"(e.g. definitions for Easy, causes/comparisons for Medium, advantages/limitations for Difficult).")
    # round-robin between levels and question types for variety
    questions = []
    per_level = {lv: list(pools[lv]) for lv in levels}
    while len(questions) < count and any(per_level.values()):
        for lv in levels:
            if per_level[lv] and len(questions) < count:
                # prefer a question type not yet used at this level
                used = {q["qtype"] for q in questions if q["difficulty"] == lv}
                idx = next((j for j, c in enumerate(per_level[lv]) if c["qtype"] not in used), 0)
                questions.append(per_level[lv].pop(idx))
    if len(questions) < count and questions:
        notes.append(f"Only {len(questions)} distinct question(s) could be generated from this material (requested {count}).")
    return {"questions": questions, "notes": notes}
