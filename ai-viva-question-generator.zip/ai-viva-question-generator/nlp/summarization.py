"""Simple extractive summarisation (top-ranked sentences kept in original order)."""
from nlp.keyword_extraction import rank_sentences


def summarize(text, n_sentences=4):
    ranked = rank_sentences(text, top_n=n_sentences)
    return [s for _, s, _ in sorted(ranked, key=lambda x: x[0])]
