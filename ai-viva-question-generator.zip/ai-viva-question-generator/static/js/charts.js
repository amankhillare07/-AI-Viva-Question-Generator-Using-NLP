// Dashboard charts - all data comes from /api/dashboard (real SQLite records).
async function loadDashboard() {
  const res = await fetch("/api/dashboard");
  const d = await res.json();
  const set = (id, v) => { document.getElementById(id).textContent = v; };
  set("s-total", d.total_questions); set("s-attempted", d.attempted); set("s-skipped", d.skipped);
  set("s-avg", d.average_score === null ? "-" : d.average_score + " / 10");
  if (!d.attempted) { document.getElementById("empty").classList.remove("d-none"); return; }
  document.getElementById("charts").classList.remove("d-none");

  const levels = ["Easy", "Medium", "Difficult"];
  new Chart(document.getElementById("levelChart"), { type: "bar",
    data: { labels: levels, datasets: [{ label: "Average score (/10)", data: levels.map(l => (d.by_level[l] || {}).avg || 0),
      backgroundColor: ["#1aa36b", "#f0a202", "#d64545"] }] },
    options: { scales: { y: { beginAtZero: true, max: 10 } }, plugins: { legend: { display: false } } } });

  new Chart(document.getElementById("statusChart"), { type: "doughnut",
    data: { labels: ["Correct", "Partial", "Weak"], datasets: [{ data: [d.status.correct, d.status.partial, d.status.weak],
      backgroundColor: ["#1aa36b", "#f0a202", "#d64545"] }] } });

  new Chart(document.getElementById("topicChart"), { type: "bar",
    data: { labels: d.by_topic.map(t => t.topic), datasets: [{ label: "Average score (/10)", data: d.by_topic.map(t => t.avg), backgroundColor: "#1e5eff" }] },
    options: { indexAxis: "y", scales: { x: { beginAtZero: true, max: 10 } }, plugins: { legend: { display: false } } } });

  new Chart(document.getElementById("trendChart"), { type: "line",
    data: { labels: d.recent.map((_, i) => i + 1), datasets: [{ label: "Score", data: d.recent.map(r => r.score), borderColor: "#1e5eff", tension: .3, fill: false }] },
    options: { scales: { y: { beginAtZero: true, max: 10 } } } });

  const ul = document.getElementById("revision");
  ul.innerHTML = d.revision.length ? d.revision.map(t => `<li class="list-group-item d-flex justify-content-between">${t.topic}<span class="badge bg-danger">${t.avg}/10</span></li>`).join("")
    : '<li class="list-group-item text-success">No weak topics - keep practising!</li>';
}
document.addEventListener("DOMContentLoaded", loadDashboard);
