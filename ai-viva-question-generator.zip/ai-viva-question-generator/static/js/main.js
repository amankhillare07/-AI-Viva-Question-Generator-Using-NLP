// Shared helpers: show a loading spinner on forms and disable the submit button to prevent double submits.
document.addEventListener("DOMContentLoaded", () => {
  document.querySelectorAll("form[data-loading]").forEach(form => {
    form.addEventListener("submit", () => {
      const btn = form.querySelector("button[type=submit]");
      if (btn) { btn.disabled = true; btn.classList.add("loading"); btn.innerHTML = '<span class="spinner-border spinner-border-sm me-2"></span>' + (form.dataset.loading || "Working..."); }
    });
  });
});
