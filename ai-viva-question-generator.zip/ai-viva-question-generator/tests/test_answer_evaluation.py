import os, sys, unittest
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))
os.environ["USE_SEMANTIC"] = "0"  # deterministic TF-IDF fallback for tests
from nlp import answer_evaluation as ev

REF = "Stemming is a technique that reduces words to their root form by removing suffixes."


class AnswerEvaluationTests(unittest.TestCase):
    def test_good_beats_bad(self):
        good = ev.evaluate_answer("Stemming reduces words to their root form by removing suffixes.", REF)
        bad = ev.evaluate_answer("Photosynthesis happens in leaves.", REF)
        self.assertGreater(good["score"], bad["score"])
        self.assertEqual(good["status"], "correct")
        self.assertEqual(bad["status"], "weak")

    def test_empty_answer(self):
        r = ev.evaluate_answer("   ", REF)
        self.assertEqual(r["score"], 0.0)

    def test_score_range(self):
        for a in ["x", "stemming", REF, REF * 3]:
            self.assertTrue(0 <= ev.evaluate_answer(a, REF)["score"] <= 10)

    def test_missing_concepts_listed(self):
        r = ev.evaluate_answer("Stemming is used on words.", REF)
        self.assertTrue(r["missing"])
        self.assertIn("stem", r["found"] + [m for m in r["missing"]] + ["stem"])

    def test_identical_answer_high(self):
        self.assertGreaterEqual(ev.evaluate_answer(REF, REF)["score"], 9.0)

    def test_tfidf_similarity_bounds(self):
        s = ev.tfidf_similarity(REF, REF)
        self.assertAlmostEqual(s, 1.0, places=3)
        self.assertEqual(ev.tfidf_similarity("", REF), 0.0)

    def test_status_thresholds(self):
        self.assertEqual(ev.status_for(8), "correct")
        self.assertEqual(ev.status_for(5), "partial")
        self.assertEqual(ev.status_for(2), "weak")


if __name__ == "__main__":
    unittest.main()
