import os, sys, unittest
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))
from nlp import preprocessing as p
from nlp.keyword_extraction import extract_keywords

TEXT = ("Tokenization splits text into tokens. Stemming reduces words to a root form. "
        "Alan Turing proposed the Turing Test in 1950. TF-IDF weights important words in documents.")


class PreprocessingTests(unittest.TestCase):
    def test_sentence_split(self):
        self.assertEqual(len(p.split_sentences(TEXT)), 4)

    def test_tokenize_and_punct(self):
        toks = p.remove_punct(p.tokenize("Hello, world!"))
        self.assertEqual(toks, ["Hello", "world"])

    def test_stopwords_removed(self):
        self.assertNotIn("the", p.remove_stopwords(["the", "cat", "is", "happy"]))

    def test_stem_and_lemma(self):
        self.assertEqual(p.stem(["studies"])[0], "studi")
        self.assertIn("study", p.lemmatize(["studies"]))

    def test_pos_tags(self):
        tags = dict(p.pos_tag(["dogs", "run"]))
        self.assertTrue(tags["dogs"].startswith("NN"))

    def test_ngrams(self):
        self.assertEqual(p.ngrams(["a", "b", "c"], 2), [("a", "b"), ("b", "c")])

    def test_word_frequency(self):
        self.assertEqual(p.word_frequency(["a", "b", "a"])[0], ("a", 2))

    def test_clean_text_fixes_pdf_breaks(self):
        self.assertEqual(p.clean_text("token-\nization is\nuseful"), "tokenization is useful")

    def test_keywords_come_from_text(self):
        kws = [k for k, _ in extract_keywords(TEXT)]
        self.assertTrue(kws)
        self.assertTrue(all(k.split()[0] in TEXT.lower() for k in kws))

    def test_empty_text(self):
        self.assertEqual(extract_keywords(""), [])

    def test_ner_if_available(self):
        if p.get_spacy() is None:
            self.skipTest("spaCy model not installed")
        labels = {e["label"] for e in p.named_entities(TEXT)}
        self.assertIn("PERSON", labels)


if __name__ == "__main__":
    unittest.main()
