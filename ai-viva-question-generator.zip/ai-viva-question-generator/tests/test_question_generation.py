import os, sys, unittest
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))
from nlp.question_generation import generate_questions

SAMPLE = open(os.path.join(os.path.dirname(__file__), "..", "data", "sample_notes.txt"), encoding="utf-8").read()


class QuestionGenerationTests(unittest.TestCase):
    def test_generates_all_levels(self):
        r = generate_questions(SAMPLE, "All", 15)
        levels = {q["difficulty"] for q in r["questions"]}
        self.assertEqual(levels, {"Easy", "Medium", "Difficult"})

    def test_count_respected(self):
        self.assertLessEqual(len(generate_questions(SAMPLE, "All", 5)["questions"]), 5)

    def test_single_level(self):
        qs = generate_questions(SAMPLE, "Easy", 6)["questions"]
        self.assertTrue(qs and all(q["difficulty"] == "Easy" for q in qs))

    def test_definition_question(self):
        qs = generate_questions(SAMPLE, "Easy", 30)["questions"]
        self.assertIn("What is Tokenization?", [q["question"] for q in qs])

    def test_grounded_and_labelled(self):
        for q in generate_questions(SAMPLE, "All", 20)["questions"]:
            self.assertTrue(q["answer"] and q["source"])
            self.assertIn(q["source"].split(".")[0][:30], SAMPLE)
            self.assertEqual(q["method"], "Rule-based")

    def test_no_duplicates(self):
        qs = [q["question"] for q in generate_questions(SAMPLE, "All", 40)["questions"]]
        self.assertEqual(len(qs), len(set(qs)))

    def test_depends_on_input(self):
        other = "Photosynthesis is the process by which plants convert light into chemical energy. " \
                "Chlorophyll is a pigment that absorbs sunlight. Plants release oxygen because water molecules are split. " \
                "Photosynthesis takes place in chloroplasts."
        qs = " ".join(q["question"] for q in generate_questions(other, "All", 10)["questions"]).lower()
        self.assertIn("photosynthesis", qs)
        self.assertNotIn("tokenization", qs)

    def test_insufficient_material_explained(self):
        r = generate_questions("Short text here. Only two sentences.", "All", 5)
        self.assertEqual(r["questions"], [])
        self.assertTrue(r["notes"])

    def test_missing_level_explained(self):
        text = "Cats are small animals. Dogs are loyal pets. Birds are able to fly. Fish live in water."
        r = generate_questions(text, "Difficult", 5)
        self.assertEqual(r["questions"], [])
        self.assertTrue(any("Difficult" in n for n in r["notes"]))


if __name__ == "__main__":
    unittest.main()
